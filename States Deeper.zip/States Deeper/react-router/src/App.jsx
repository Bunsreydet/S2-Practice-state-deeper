import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Footer } from "./components/footer/footer";
import { NavHeader } from "./components/nav/nav-header";
import { Home } from "./pages/home";
import { Layout } from "./components/layout/layout";
import { About } from "./pages/about";
import { History } from "./pages/history"
import { Projects } from "./pages/projects";
import { Careers } from "./pages/careers";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />}></Route>
          <Route path="/about" element={<About />}></Route>
          <Route path="/history" element={<History />}></Route>
          <Route path="/projects" element={<Projects/>}></Route>
          <Route path="careers" element={<Careers/>}></Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
