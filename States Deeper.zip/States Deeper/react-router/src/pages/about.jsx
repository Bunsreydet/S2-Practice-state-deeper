import { Testimony } from "../components/heros/testimony";

export function About() {
  return (
    <div>
      <Testimony />
    </div>
  );
}
