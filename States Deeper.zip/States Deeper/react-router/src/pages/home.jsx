import { NavHeader } from "../components/nav/nav-header";
import { Banner } from "../components/heros/banner";
import { Footer } from "../components/footer/footer";

export function Home() {
  return (
    <>
      <Banner/>
    </>
  );
}
